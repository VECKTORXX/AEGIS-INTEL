// Free forever: Ollama runs AI models 100% locally on your machine
// Install: https://ollama.com  |  then run: ollama pull mistral
// No API key. No account. No internet required after model download.

const SYSTEM_PROMPT = `You are AEGIS, an elite military cyber intelligence analyst AI.
Your role: analyze threats, CVEs, APT groups, and cyber warfare intelligence.
Style: tactical, precise, use military/cyber terminology. Max 120 words per response.
Format responses with clear structure. Reference real threat actors (APT28, Lazarus Group etc),
real CVE IDs, MITRE ATT&CK techniques when relevant. Always assess severity and recommend action.`;

export async function askOllama(userMessage, model = 'mistral') {
  const fullPrompt = `${SYSTEM_PROMPT}\n\nOperator query: ${userMessage}\n\nAEGIS analysis:`;

  if (window.aegis) {
    return window.aegis.askOllama({ prompt: fullPrompt, model });
  }

  // Direct Ollama call for dev/browser mode
  try {
    const res = await fetch('http://localhost:11434/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, prompt: fullPrompt, stream: false })
    });
    const data = await res.json();
    return { response: data.response };
  } catch (e) {
    return {
      error: `Ollama offline. Steps to fix:\n1. Download from ollama.com\n2. Install and run Ollama\n3. Open terminal: ollama pull mistral\n4. Restart AEGIS Intel`
    };
  }
}

export const AVAILABLE_MODELS = [
  { id: 'mistral',        name: 'Mistral 7B',     size: '4.1GB', recommended: true },
  { id: 'llama3',         name: 'LLaMA 3 8B',     size: '4.7GB', recommended: false },
  { id: 'phi3',           name: 'Phi-3 Mini',     size: '2.3GB', recommended: false },
  { id: 'gemma2',         name: 'Gemma 2 9B',     size: '5.5GB', recommended: false },
  { id: 'openchat',       name: 'OpenChat 3.5',   size: '4.1GB', recommended: false },
];
