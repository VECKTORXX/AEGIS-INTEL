// PDF Report Generator — uses browser print API (free forever, no library needed)
// Generates a styled military intel report and opens the print dialog

export function exportThreatReport({ cves = [], metrics = {}, config = {} }) {
  const now = new Date();
  const dateStr = now.toISOString().split('T')[0];
  const timeStr = now.toUTCString().split(' ')[4] + ' UTC';

  const severityColor = s => ({
    CRITICAL: '#ef4444', HIGH: '#f59e0b', MEDIUM: '#00e5ff', LOW: '#00ff88'
  })[s] || '#5a8a9a';

  const cveRows = cves.slice(0, 30).map(c => `
    <tr>
      <td style="font-family:monospace;font-size:11px;color:#00e5ff;padding:5px 8px;border-bottom:1px solid #1a3040">${c.id}</td>
      <td style="font-size:11px;padding:5px 8px;border-bottom:1px solid #1a3040;color:${severityColor(c.severity)};font-weight:700">${c.severity}</td>
      <td style="font-size:11px;padding:5px 8px;border-bottom:1px solid #1a3040;color:#c8e8f0">${c.score || 'N/A'}</td>
      <td style="font-size:10px;padding:5px 8px;border-bottom:1px solid #1a3040;color:#8aacb8;max-width:320px">${(c.description || '').slice(0, 120)}...</td>
      <td style="font-family:monospace;font-size:10px;padding:5px 8px;border-bottom:1px solid #1a3040;color:#5a8a9a">${(c.published || '').split('T')[0]}</td>
    </tr>
  `).join('');

  const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>AEGIS Intel Report — ${dateStr}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@400;700&display=swap');
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { background: #070b0f; color: #c8e8f0; font-family: 'Share Tech Mono', monospace; padding: 40px; }
    .header { border-bottom: 2px solid #00e5ff; padding-bottom: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: flex-end; }
    .logo { font-family: 'Orbitron', sans-serif; font-size: 28px; font-weight: 700; color: #00e5ff; letter-spacing: 0.2em; }
    .meta { text-align: right; font-size: 11px; color: #5a8a9a; line-height: 1.8; }
    .section-title { font-family: 'Orbitron', sans-serif; font-size: 11px; letter-spacing: 0.2em; color: #00e5ff; margin: 24px 0 12px; border-left: 3px solid #00e5ff; padding-left: 10px; }
    .grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 12px; margin-bottom: 20px; }
    .stat-card { background: #0d1520; border: 1px solid #1a3040; border-radius: 6px; padding: 12px; }
    .stat-label { font-size: 10px; color: #5a8a9a; margin-bottom: 4px; letter-spacing: 0.1em; }
    .stat-val { font-family: 'Orbitron', sans-serif; font-size: 22px; font-weight: 700; color: #00e5ff; }
    table { width: 100%; border-collapse: collapse; background: #0d1520; border: 1px solid #1a3040; border-radius: 6px; overflow: hidden; }
    thead tr { background: #111d2e; }
    thead th { font-size: 10px; letter-spacing: 0.1em; color: #5a8a9a; padding: 8px 8px; text-align: left; border-bottom: 1px solid #1a3040; }
    .footer { margin-top: 40px; border-top: 1px solid #1a3040; padding-top: 16px; font-size: 10px; color: #2a4a5a; display: flex; justify-content: space-between; }
    .classified { color: #ef4444; font-family: 'Orbitron', sans-serif; font-size: 11px; letter-spacing: 0.2em; }
    @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <div class="logo">AEGIS INTEL</div>
      <div style="font-size:12px;color:#5a8a9a;margin-top:4px;letter-spacing:0.1em">CYBER INTELLIGENCE REPORT</div>
    </div>
    <div class="meta">
      <div>GENERATED: ${dateStr} ${timeStr}</div>
      <div>REPORT ID: AEGIS-${Date.now().toString(36).toUpperCase()}</div>
      <div>OPERATOR: ${config.operatorName || 'CLASSIFIED'}</div>
    </div>
  </div>

  <div class="classified">// UNCLASSIFIED — FOR AUTHORIZED USE ONLY //</div>

  <div class="section-title">EXECUTIVE METRICS</div>
  <div class="grid">
    <div class="stat-card"><div class="stat-label">TOTAL CVEs</div><div class="stat-val" style="color:#00e5ff">${cves.length}</div></div>
    <div class="stat-card"><div class="stat-label">CRITICAL</div><div class="stat-val" style="color:#ef4444">${cves.filter(c=>c.severity==='CRITICAL').length}</div></div>
    <div class="stat-card"><div class="stat-label">HIGH</div><div class="stat-val" style="color:#f59e0b">${cves.filter(c=>c.severity==='HIGH').length}</div></div>
    <div class="stat-card"><div class="stat-label">REPORT DATE</div><div style="font-family:'Orbitron',sans-serif;font-size:13px;font-weight:700;color:#00ff88;margin-top:4px">${dateStr}</div></div>
  </div>

  <div class="section-title">VULNERABILITY INTELLIGENCE (TOP 30)</div>
  <table>
    <thead>
      <tr>
        <th>CVE ID</th><th>SEVERITY</th><th>CVSS</th><th>DESCRIPTION</th><th>PUBLISHED</th>
      </tr>
    </thead>
    <tbody>${cveRows}</tbody>
  </table>

  <div class="footer">
    <div>AEGIS INTEL v2.4 — FREE FOREVER BUILD — POWERED BY NIST NVD + OLLAMA</div>
    <div class="classified">// END OF REPORT //</div>
  </div>
</body>
</html>`;

  const win = window.open('', '_blank');
  win.document.write(html);
  win.document.close();
  setTimeout(() => win.print(), 800);
}
