// Free forever: NIST NVD CVE API — no key required
// Docs: https://nvd.nist.gov/developers/vulnerabilities

export async function fetchLatestCVEs() {
  // Use Electron IPC if available, otherwise call directly (for browser dev mode)
  if (window.aegis) {
    return window.aegis.fetchCVEs();
  }
  // Direct call for browser-only dev mode
  try {
    const res = await fetch(
      'https://services.nvd.nist.gov/rest/json/cves/2.0?resultsPerPage=20'
    );
    const data = await res.json();
    return data.vulnerabilities.map(v => ({
      id: v.cve.id,
      description: v.cve.descriptions.find(d => d.lang === 'en')?.value || '',
      severity: v.cve.metrics?.cvssMetricV31?.[0]?.cvssData?.baseSeverity || 'UNKNOWN',
      score: v.cve.metrics?.cvssMetricV31?.[0]?.cvssData?.baseScore || 0,
      published: v.cve.published,
    }));
  } catch (e) {
    return { error: e.message };
  }
}

export function severityColor(sev) {
  switch ((sev || '').toUpperCase()) {
    case 'CRITICAL': return '#ef4444';
    case 'HIGH':     return '#f59e0b';
    case 'MEDIUM':   return '#00e5ff';
    case 'LOW':      return '#00ff88';
    default:         return '#5a8a9a';
  }
}

export function severityBg(sev) {
  switch ((sev || '').toUpperCase()) {
    case 'CRITICAL': return '#2a0808';
    case 'HIGH':     return '#2a1a04';
    case 'MEDIUM':   return '#042a30';
    case 'LOW':      return '#042a12';
    default:         return '#0d1520';
  }
}
