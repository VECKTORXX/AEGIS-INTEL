// Desktop notification service
// Uses Electron's native Notification API via IPC when in desktop mode
// Falls back to browser Notification API in web dev mode

export function requestNotificationPermission() {
  if (window.aegis) return; // Electron handles permissions
  if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
  }
}

export function sendNotification(title, body, urgency = 'normal') {
  // Electron desktop notification
  if (window.aegis) {
    window.aegis.notify({ title, body });
    return;
  }
  // Browser fallback
  if ('Notification' in window && Notification.permission === 'granted') {
    new Notification(title, { body, icon: '/icon.png' });
  }
}

export function checkCVEsForAlerts(cves, config, previousIds = new Set()) {
  const alerts = [];
  cves.forEach(cve => {
    if (previousIds.has(cve.id)) return;
    const sev = (cve.severity || '').toUpperCase();
    const desc = (cve.description || '').toLowerCase();
    const keywords = (config.watchKeywords || '')
      .split(',').map(k => k.trim().toLowerCase()).filter(Boolean);

    const isKeywordMatch = keywords.some(k => desc.includes(k) || cve.id.toLowerCase().includes(k));
    const isCritical = sev === 'CRITICAL' && config.notifyCritical;
    const isHigh     = sev === 'HIGH'     && config.notifyHigh;

    if (isCritical || isHigh || isKeywordMatch) {
      alerts.push(cve);
      const title = isKeywordMatch
        ? `AEGIS — Keyword match: ${cve.id}`
        : `AEGIS — ${sev} CVE: ${cve.id}`;
      sendNotification(title, cve.description?.slice(0, 100) + '...', 'critical');
    }
  });
  return alerts;
}
