import React, { useState, useEffect } from 'react';

const THREAT_SOURCES = [
  { country: 'Russia (APT28/29)', code: 'RU', pct: 88, color: 'var(--red)' },
  { country: 'China (APT40/41)',  code: 'CN', pct: 74, color: 'var(--amber)' },
  { country: 'N. Korea (Lazarus)',code: 'KP', pct: 61, color: 'var(--amber)' },
  { country: 'Iran (APT33/34)',   code: 'IR', pct: 49, color: 'var(--accent)' },
  { country: 'Unknown / Other',  code: '??', pct: 33, color: 'var(--text-sec)' },
];

const ATTACK_VECTORS = [
  { name: 'Spear phishing',    pct: 72, color: 'var(--accent)' },
  { name: 'Exploit kit',       pct: 55, color: 'var(--amber)' },
  { name: 'Supply chain',      pct: 38, color: 'var(--red)' },
  { name: 'Brute force / cred',pct: 31, color: 'var(--green)' },
  { name: 'Zero-day exploit',  pct: 22, color: 'var(--red)' },
];

export default function ThreatMetrics({ cveCount }) {
  const [metrics, setMetrics] = useState({ total: 247, critical: 12, high: 38, active: 3 });

  useEffect(() => {
    const id = setInterval(() => {
      setMetrics(m => ({
        ...m,
        total: m.total + Math.floor(Math.random() * 2),
        active: Math.max(1, m.active + (Math.random() > 0.7 ? 1 : -1)),
      }));
    }, 5000);
    return () => clearInterval(id);
  }, []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10, height: '100%', overflowY: 'auto' }}>
      <SectionTitle>THREAT METRICS</SectionTitle>

      {/* Stat cards */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        <StatCard label="Total threats" value={metrics.total} color="var(--text-pri)" />
        <StatCard label="Critical" value={metrics.critical} color="var(--red)" />
        <StatCard label="High severity" value={metrics.high} color="var(--amber)" />
        <StatCard label="CVEs tracked" value={cveCount} color="var(--accent)" />
      </div>

      <Divider />
      <SectionTitle>THREAT ORIGIN</SectionTitle>
      {THREAT_SOURCES.map(s => (
        <BarRow key={s.code} label={s.country} pct={s.pct} color={s.color} />
      ))}

      <Divider />
      <SectionTitle>ATTACK VECTORS</SectionTitle>
      {ATTACK_VECTORS.map(v => (
        <BarRow key={v.name} label={v.name} pct={v.pct} color={v.color} />
      ))}

      <Divider />
      <SectionTitle>ACTIVE INCIDENTS</SectionTitle>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
        {[
          { id: 'INC-4421', label: 'OpenSSL RCE exploit active', color: 'var(--red)' },
          { id: 'INC-4418', label: 'APT-29 phishing wave EU', color: 'var(--amber)' },
          { id: 'INC-4415', label: 'SCADA scan wave detected', color: 'var(--accent)' },
        ].map(inc => (
          <div key={inc.id} style={{
            display: 'flex', alignItems: 'center', gap: 8,
            background: 'var(--bg-card)', border: `1px solid var(--border)`,
            borderLeft: `3px solid ${inc.color}`,
            borderRadius: 4, padding: '5px 8px',
          }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: inc.color }}>
              {inc.id}
            </span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-sec)', flex: 1 }}>
              {inc.label}
            </span>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: inc.color, animation: 'pulse 1.5s infinite' }} />
          </div>
        ))}
      </div>
    </div>
  );
}

function StatCard({ label, value, color }) {
  return (
    <div style={{
      background: 'var(--bg-card)', border: '1px solid var(--border)',
      borderRadius: 4, padding: '8px 10px',
    }}>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-dim)', marginBottom: 2 }}>
        {label.toUpperCase()}
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color, lineHeight: 1 }}>
        {value}
      </div>
    </div>
  );
}

function BarRow({ label, pct, color }) {
  const [animated, setAnimated] = useState(0);
  useEffect(() => { setTimeout(() => setAnimated(pct), 100); }, [pct]);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-sec)', minWidth: 130, flexShrink: 0 }}>
        {label}
      </span>
      <div style={{ flex: 1, height: 5, background: 'var(--bg-base)', borderRadius: 3, overflow: 'hidden' }}>
        <div style={{ height: '100%', width: `${animated}%`, background: color, borderRadius: 3, transition: 'width 1s ease' }} />
      </div>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color, minWidth: 28, textAlign: 'right' }}>
        {pct}%
      </span>
    </div>
  );
}

function SectionTitle({ children }) {
  return (
    <div style={{ fontFamily: 'var(--font-display)', fontSize: 10, letterSpacing: '0.15em', color: 'var(--accent)', marginTop: 2 }}>
      {children}
    </div>
  );
}

function Divider() {
  return <div style={{ borderTop: '1px solid var(--border)' }} />;
}
