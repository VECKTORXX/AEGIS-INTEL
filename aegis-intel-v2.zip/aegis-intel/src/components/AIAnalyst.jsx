import React, { useState, useRef, useEffect } from 'react';
import { askOllama, AVAILABLE_MODELS } from '../services/ollamaService';

const QUICK_QUERIES = [
  'What are the top APT groups active right now?',
  'Explain MITRE ATT&CK techniques used by Lazarus Group',
  'How should I defend against ransomware in 2025?',
  'What is lateral movement and how to detect it?',
  'Explain zero-day vs n-day vulnerabilities',
];

export default function AIAnalyst({ onStatusChange }) {
  const [messages, setMessages] = useState([
    {
      role: 'ai',
      text: 'AEGIS online. I am your military cyber intelligence analyst running locally on your machine — no cloud, no account, no cost. I analyze threats, CVEs, APT groups, and attack vectors. How can I assist, operator?',
      ts: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [model, setModel] = useState('mistral');
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const send = async (text) => {
    const q = (text || input).trim();
    if (!q || loading) return;
    setInput('');
    setMessages(m => [...m, { role: 'user', text: q, ts: new Date() }]);
    setLoading(true);
    onStatusChange?.('thinking');

    const result = await askOllama(q, model);

    setLoading(false);
    if (result.error) {
      setMessages(m => [...m, { role: 'error', text: result.error, ts: new Date() }]);
      onStatusChange?.('offline');
    } else {
      setMessages(m => [...m, { role: 'ai', text: result.response, ts: new Date() }]);
      onStatusChange?.('online');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: 11, letterSpacing: '0.15em', color: 'var(--accent)' }}>
          AI ANALYST — POWERED BY OLLAMA
        </span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-dim)' }}>MODEL:</span>
          <select value={model} onChange={e => setModel(e.target.value)} style={{
            background: 'var(--bg-input)', border: '1px solid var(--border)',
            color: 'var(--text-sec)', fontFamily: 'var(--font-mono)', fontSize: 10,
            padding: '2px 6px', borderRadius: 3, cursor: 'pointer'
          }}>
            {AVAILABLE_MODELS.map(m => (
              <option key={m.id} value={m.id}>
                {m.name} ({m.size}){m.recommended ? ' ★' : ''}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Ollama setup notice */}
      <div style={{
        background: '#041a10', border: '1px solid var(--green-dim)',
        borderRadius: 4, padding: '6px 10px', marginBottom: 8,
        fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--green-dim)',
        lineHeight: 1.6
      }}>
        FREE FOREVER: Install Ollama → ollama.com | Run: <span style={{ color: 'var(--green)' }}>ollama pull mistral</span>
      </div>

      {/* Message list */}
      <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 8 }}>
        {messages.map((msg, i) => (
          <MessageBubble key={i} msg={msg} />
        ))}
        {loading && <ThinkingIndicator />}
        <div ref={bottomRef} />
      </div>

      {/* Quick query buttons */}
      <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 8 }}>
        {QUICK_QUERIES.slice(0, 3).map((q, i) => (
          <button key={i} onClick={() => send(q)} disabled={loading} style={{
            background: 'var(--bg-card)', border: '1px solid var(--border)',
            color: 'var(--text-sec)', fontFamily: 'var(--font-mono)', fontSize: 10,
            padding: '3px 7px', borderRadius: 3, cursor: 'pointer',
            transition: 'all .15s', maxWidth: 180, overflow: 'hidden',
            textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.color = 'var(--accent)'; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.color = 'var(--text-sec)'; }}
          >
            {q.length > 28 ? q.slice(0, 28) + '…' : q}
          </button>
        ))}
      </div>

      {/* Input row */}
      <div style={{ display: 'flex', gap: 6 }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
          disabled={loading}
          placeholder="Query the AI analyst... (Enter to send)"
          style={{
            flex: 1, background: 'var(--bg-input)',
            border: '1px solid var(--border)', borderRadius: 4,
            padding: '7px 10px', color: 'var(--text-pri)',
            fontFamily: 'var(--font-mono)', fontSize: 12, outline: 'none',
            transition: 'border-color .15s',
          }}
          onFocus={e => { e.target.style.borderColor = 'var(--accent)'; }}
          onBlur={e => { e.target.style.borderColor = 'var(--border)'; }}
        />
        <button onClick={() => send()} disabled={loading || !input.trim()} style={{
          background: loading ? 'var(--bg-card)' : 'var(--bg-input)',
          border: `1px solid ${loading ? 'var(--border)' : 'var(--accent)'}`,
          color: loading ? 'var(--text-dim)' : 'var(--accent)',
          fontFamily: 'var(--font-mono)', fontSize: 11, padding: '7px 14px',
          borderRadius: 4, cursor: loading ? 'not-allowed' : 'pointer',
          letterSpacing: '0.05em', transition: 'all .15s',
        }}>
          {loading ? '...' : 'SEND →'}
        </button>
      </div>
    </div>
  );
}

function MessageBubble({ msg }) {
  const isUser  = msg.role === 'user';
  const isError = msg.role === 'error';
  return (
    <div style={{
      alignSelf: isUser ? 'flex-end' : 'flex-start',
      maxWidth: '88%',
      animation: 'slideIn .2s ease',
    }}>
      <div style={{ marginBottom: 3, display: 'flex', gap: 6, alignItems: 'center',
        justifyContent: isUser ? 'flex-end' : 'flex-start'
      }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10,
          color: isUser ? 'var(--amber)' : isError ? 'var(--red)' : 'var(--accent)'
        }}>
          {isUser ? 'OPERATOR' : isError ? 'SYSTEM ERROR' : 'AEGIS'}
        </span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-dim)' }}>
          {msg.ts?.toTimeString().split(' ')[0]}
        </span>
      </div>
      <div style={{
        background: isUser ? '#1a2a10' : isError ? '#2a0808' : 'var(--bg-card)',
        border: `1px solid ${isUser ? 'var(--green-dim)' : isError ? 'var(--red)' : 'var(--border)'}`,
        borderLeft: `3px solid ${isUser ? 'var(--amber)' : isError ? 'var(--red)' : 'var(--accent)'}`,
        borderRadius: 4, padding: '8px 12px',
        fontFamily: 'var(--font-mono)', fontSize: 12,
        color: isError ? 'var(--red)' : 'var(--text-pri)',
        lineHeight: 1.6, whiteSpace: 'pre-wrap',
      }}>
        {msg.text}
      </div>
    </div>
  );
}

function ThinkingIndicator() {
  return (
    <div style={{ alignSelf: 'flex-start' }}>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--accent)', marginBottom: 3 }}>
        AEGIS
      </div>
      <div style={{
        background: 'var(--bg-card)', border: '1px solid var(--border)',
        borderLeft: '3px solid var(--accent)', borderRadius: 4,
        padding: '8px 16px', display: 'flex', gap: 4, alignItems: 'center'
      }}>
        {[0, 150, 300].map(d => (
          <div key={d} style={{
            width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)',
            animation: 'pulse 1s infinite', animationDelay: `${d}ms`
          }} />
        ))}
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-sec)', marginLeft: 4 }}>
          ANALYZING...
        </span>
      </div>
    </div>
  );
}
