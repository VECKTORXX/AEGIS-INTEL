import React, { useState, useEffect } from 'react';
import { AVAILABLE_MODELS } from '../services/ollamaService';

const S = {
  overlay: {
    position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.75)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    zIndex: 1000, animation: 'fadeIn .15s ease',
  },
  modal: {
    background: '#0d1520', border: '1px solid #1a3040',
    borderRadius: 8, width: 560, maxHeight: '80vh',
    display: 'flex', flexDirection: 'column', overflow: 'hidden',
  },
  header: {
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '14px 18px', borderBottom: '1px solid #1a3040',
  },
  body: { padding: '18px', overflowY: 'auto', flex: 1 },
  section: { marginBottom: 22 },
  sectionTitle: {
    fontFamily: 'var(--font-display)', fontSize: 10,
    letterSpacing: '0.15em', color: 'var(--accent)',
    marginBottom: 10,
  },
  row: { marginBottom: 12 },
  label: {
    fontFamily: 'var(--font-mono)', fontSize: 11,
    color: 'var(--text-sec)', marginBottom: 5, display: 'block',
  },
  input: {
    width: '100%', background: '#070b0f',
    border: '1px solid #1a3040', borderRadius: 4,
    padding: '8px 10px', color: 'var(--text-pri)',
    fontFamily: 'var(--font-mono)', fontSize: 12,
    outline: 'none', transition: 'border-color .15s',
  },
  hint: {
    fontFamily: 'var(--font-mono)', fontSize: 10,
    color: '#2a4a5a', marginTop: 4,
  },
  btn: {
    background: 'transparent', border: '1px solid #1a3040',
    color: 'var(--text-sec)', fontFamily: 'var(--font-mono)',
    fontSize: 11, padding: '6px 14px', borderRadius: 4,
    cursor: 'pointer', letterSpacing: '0.05em', transition: 'all .15s',
  },
  btnPrimary: {
    background: '#042a30', border: '1px solid var(--accent)',
    color: 'var(--accent)', fontFamily: 'var(--font-mono)',
    fontSize: 11, padding: '6px 14px', borderRadius: 4,
    cursor: 'pointer', letterSpacing: '0.05em', transition: 'all .15s',
  },
};

export default function SettingsModal({ config, onSave, onClose }) {
  const [cfg, setCfg] = useState({ ...config });
  const [saved, setSaved] = useState(false);
  const [abuseKeyVisible, setAbuseKeyVisible] = useState(false);

  const set = (key, val) => setCfg(c => ({ ...c, [key]: val }));

  const save = () => {
    onSave(cfg);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div style={S.overlay} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={S.modal}>
        <div style={S.header}>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: 12, letterSpacing: '0.15em', color: 'var(--accent)' }}>
            SYSTEM CONFIGURATION
          </span>
          <button onClick={onClose} style={{ ...S.btn, padding: '3px 8px', fontSize: 13 }}>✕</button>
        </div>

        <div style={S.body}>
          {/* AI Engine */}
          <div style={S.section}>
            <div style={S.sectionTitle}>AI ENGINE — OLLAMA (FREE FOREVER)</div>
            <div style={S.row}>
              <label style={S.label}>DEFAULT MODEL</label>
              <select value={cfg.ollamaModel} onChange={e => set('ollamaModel', e.target.value)}
                style={{ ...S.input, cursor: 'pointer' }}>
                {AVAILABLE_MODELS.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.name} — {m.size}{m.recommended ? ' (recommended)' : ''}
                  </option>
                ))}
              </select>
              <div style={S.hint}>Install models with: ollama pull {'<model>'}</div>
            </div>
            <div style={S.row}>
              <label style={S.label}>OLLAMA HOST URL</label>
              <input style={S.input} value={cfg.ollamaUrl}
                onChange={e => set('ollamaUrl', e.target.value)}
                placeholder="http://localhost:11434"
                onFocus={e => e.target.style.borderColor = 'var(--accent)'}
                onBlur={e => e.target.style.borderColor = '#1a3040'} />
              <div style={S.hint}>Default: http://localhost:11434 — change if Ollama runs on another machine</div>
            </div>
          </div>

          {/* AbuseIPDB */}
          <div style={S.section}>
            <div style={S.sectionTitle}>ABUSEIPDB — IP REPUTATION (FREE TIER)</div>
            <div style={S.row}>
              <label style={S.label}>API KEY</label>
              <div style={{ display: 'flex', gap: 6 }}>
                <input
                  style={{ ...S.input, flex: 1 }}
                  type={abuseKeyVisible ? 'text' : 'password'}
                  value={cfg.abuseIpDbKey}
                  onChange={e => set('abuseIpDbKey', e.target.value)}
                  placeholder="Paste your AbuseIPDB API key here"
                  onFocus={e => e.target.style.borderColor = 'var(--accent)'}
                  onBlur={e => e.target.style.borderColor = '#1a3040'} />
                <button onClick={() => setAbuseKeyVisible(v => !v)}
                  style={{ ...S.btn, padding: '6px 10px', flexShrink: 0 }}>
                  {abuseKeyVisible ? 'HIDE' : 'SHOW'}
                </button>
              </div>
              <div style={S.hint}>
                Free signup at abuseipdb.com — no credit card needed. 1,000 checks/day free forever.
              </div>
            </div>
          </div>

          {/* CVE Feed */}
          <div style={S.section}>
            <div style={S.sectionTitle}>CVE FEED — NIST NVD (FREE FOREVER)</div>
            <div style={S.row}>
              <label style={S.label}>RESULTS PER REFRESH</label>
              <select value={cfg.cveLimit} onChange={e => set('cveLimit', Number(e.target.value))}
                style={{ ...S.input, cursor: 'pointer' }}>
                {[10, 20, 50, 100].map(n => (
                  <option key={n} value={n}>{n} vulnerabilities</option>
                ))}
              </select>
            </div>
            <div style={S.row}>
              <label style={S.label}>AUTO-REFRESH INTERVAL</label>
              <select value={cfg.cveRefreshMins} onChange={e => set('cveRefreshMins', Number(e.target.value))}
                style={{ ...S.input, cursor: 'pointer' }}>
                {[0, 5, 15, 30, 60].map(n => (
                  <option key={n} value={n}>{n === 0 ? 'Manual only' : `Every ${n} minutes`}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Notifications */}
          <div style={S.section}>
            <div style={S.sectionTitle}>DESKTOP NOTIFICATIONS</div>
            {[
              { key: 'notifyCritical', label: 'Alert on CRITICAL CVEs' },
              { key: 'notifyHigh',     label: 'Alert on HIGH severity CVEs' },
              { key: 'notifyNewIP',    label: 'Alert on new malicious IPs' },
            ].map(({ key, label }) => (
              <div key={key} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                <div onClick={() => set(key, !cfg[key])} style={{
                  width: 32, height: 18, borderRadius: 9,
                  background: cfg[key] ? 'var(--accent)' : '#1a3040',
                  position: 'relative', cursor: 'pointer', transition: 'background .2s', flexShrink: 0,
                }}>
                  <div style={{
                    position: 'absolute', top: 2,
                    left: cfg[key] ? 14 : 2,
                    width: 14, height: 14, borderRadius: '50%',
                    background: '#fff', transition: 'left .2s',
                  }} />
                </div>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-sec)' }}>
                  {label}
                </span>
              </div>
            ))}
          </div>

          {/* Keyword watchlist */}
          <div style={S.section}>
            <div style={S.sectionTitle}>CVE KEYWORD WATCHLIST</div>
            <div style={S.row}>
              <label style={S.label}>WATCH FOR THESE KEYWORDS (comma separated)</label>
              <input style={S.input} value={cfg.watchKeywords}
                onChange={e => set('watchKeywords', e.target.value)}
                placeholder="nginx, windows, apache, openssl, docker"
                onFocus={e => e.target.style.borderColor = 'var(--accent)'}
                onBlur={e => e.target.style.borderColor = '#1a3040'} />
              <div style={S.hint}>CVEs matching these keywords will be highlighted and trigger alerts</div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{
          display: 'flex', justifyContent: 'flex-end', gap: 8,
          padding: '12px 18px', borderTop: '1px solid #1a3040',
        }}>
          <button onClick={onClose} style={S.btn}
            onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--accent)'}
            onMouseLeave={e => e.currentTarget.style.borderColor = '#1a3040'}>
            CANCEL
          </button>
          <button onClick={save} style={S.btnPrimary}>
            {saved ? '✓ SAVED' : 'SAVE CONFIG'}
          </button>
        </div>
      </div>
    </div>
  );
}
