import React from 'react';

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard',  icon: '▦' },
  { id: 'cve',       label: 'CVE Feed',   icon: '⚠' },
  { id: 'map',       label: 'World Map',  icon: '◈' },
  { id: 'ipscan',    label: 'IP Scanner', icon: '⊕' },
  { id: 'ai',        label: 'AI Analyst', icon: '◎' },
];

export default function Sidebar({ active, onNav, alertCount }) {
  return (
    <div style={{
      width: 56, background: 'var(--bg-panel)',
      borderRight: '1px solid var(--border)',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', paddingTop: 8, gap: 4,
      flexShrink: 0,
    }}>
      {NAV_ITEMS.map(item => (
        <button key={item.id} onClick={() => onNav(item.id)}
          title={item.label}
          style={{
            width: 40, height: 40, borderRadius: 6,
            background: active === item.id ? '#042a30' : 'transparent',
            border: active === item.id ? '1px solid var(--accent)' : '1px solid transparent',
            color: active === item.id ? 'var(--accent)' : 'var(--text-dim)',
            fontSize: 16, cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            transition: 'all .15s', position: 'relative',
          }}
          onMouseEnter={e => { if (active !== item.id) { e.currentTarget.style.color = 'var(--text-sec)'; e.currentTarget.style.borderColor = 'var(--border)'; }}}
          onMouseLeave={e => { if (active !== item.id) { e.currentTarget.style.color = 'var(--text-dim)'; e.currentTarget.style.borderColor = 'transparent'; }}}
        >
          {item.icon}
          {item.id === 'cve' && alertCount > 0 && (
            <div style={{
              position: 'absolute', top: 4, right: 4,
              width: 8, height: 8, borderRadius: '50%',
              background: 'var(--red)', animation: 'pulse 1.5s infinite',
            }} />
          )}
        </button>
      ))}

      {/* Spacer */}
      <div style={{ flex: 1 }} />

      {/* Settings button */}
      <button style={{
        width: 40, height: 40, borderRadius: 6,
        background: 'transparent', border: '1px solid transparent',
        color: 'var(--text-dim)', fontSize: 16, cursor: 'pointer',
        marginBottom: 8, transition: 'all .15s',
      }}
        title="Settings"
        onMouseEnter={e => { e.currentTarget.style.color = 'var(--accent)'; e.currentTarget.style.borderColor = 'var(--border)'; }}
        onMouseLeave={e => { e.currentTarget.style.color = 'var(--text-dim)'; e.currentTarget.style.borderColor = 'transparent'; }}
        onClick={() => onNav('settings')}
      >⚙</button>
    </div>
  );
}
