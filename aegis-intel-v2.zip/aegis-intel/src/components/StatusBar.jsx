import React, { useState, useEffect } from 'react';

export default function StatusBar({ threatCount, cveCount, aiStatus }) {
  const [uptime, setUptime] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setUptime(u => u + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const fmt = s => {
    const h = String(Math.floor(s / 3600)).padStart(2, '0');
    const m = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
    const sec = String(s % 60).padStart(2, '0');
    return `${h}:${m}:${sec}`;
  };

  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 24,
      height: 28, padding: '0 16px',
      background: 'var(--bg-panel)',
      borderTop: '1px solid var(--border)',
      flexShrink: 0,
      fontFamily: 'var(--font-mono)', fontSize: 11,
    }}>
      <Item dot="var(--green)" label="FEEDS" value="LIVE" color="var(--green)" />
      <Item dot={aiStatus === 'online' ? 'var(--green)' : 'var(--red)'}
            label="AI ENGINE"
            value={aiStatus.toUpperCase()}
            color={aiStatus === 'online' ? 'var(--green)' : 'var(--red)'} />
      <Item label="THREATS" value={threatCount} color="var(--amber)" />
      <Item label="CVEs TRACKED" value={cveCount} color="var(--accent)" />
      <div style={{ marginLeft: 'auto', color: 'var(--text-dim)' }}>
        UPTIME <span style={{ color: 'var(--text-sec)' }}>{fmt(uptime)}</span>
      </div>
      <div style={{ color: 'var(--text-dim)' }}>
        AEGIS INTEL © 2025 — FREE FOREVER BUILD
      </div>
    </div>
  );
}

function Item({ dot, label, value, color }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      {dot && <div style={{ width: 6, height: 6, borderRadius: '50%', background: dot, animation: 'pulse 2s infinite' }} />}
      <span style={{ color: 'var(--text-dim)' }}>{label}:</span>
      <span style={{ color: color || 'var(--text-sec)' }}>{value}</span>
    </div>
  );
}
