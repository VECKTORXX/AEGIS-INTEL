import React, { useState, useEffect, useCallback } from 'react';
import { fetchLatestCVEs, severityColor, severityBg } from '../services/cveService';

export default function CVEFeed({ onThreatCountChange }) {
  const [cves, setCves] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastRefresh, setLastRefresh] = useState(null);
  const [selected, setSelected] = useState(null);
  const [filter, setFilter] = useState('ALL');

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const data = await fetchLatestCVEs();
    if (data?.error) { setError(data.error); setLoading(false); return; }
    setCves(data);
    setLastRefresh(new Date());
    onThreatCountChange?.(data.length);
    setLoading(false);
  }, [onThreatCountChange]);

  useEffect(() => { load(); }, [load]);

  const filtered = filter === 'ALL' ? cves : cves.filter(c => c.severity === filter);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: 11, letterSpacing: '0.15em', color: 'var(--accent)' }}>
          CVE INTELLIGENCE FEED
        </span>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          {lastRefresh && (
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-dim)' }}>
              {lastRefresh.toTimeString().split(' ')[0]}
            </span>
          )}
          <button onClick={load} disabled={loading} style={btnStyle}>
            {loading ? '...' : '↻ REFRESH'}
          </button>
        </div>
      </div>

      {/* Severity filters */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 8 }}>
        {['ALL', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{
            ...btnStyle,
            color: f === 'ALL' ? 'var(--text-sec)' : severityColor(f),
            borderColor: filter === f ? (f === 'ALL' ? 'var(--accent)' : severityColor(f)) : 'var(--border)',
            background: filter === f ? severityBg(f) : 'transparent',
            fontSize: 10,
          }}>{f}</button>
        ))}
      </div>

      {/* Feed list */}
      <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 4 }}>
        {error && <ErrorBox msg={error} onRetry={load} />}
        {loading && <LoadingRows />}
        {!loading && filtered.map((cve, i) => (
          <CVERow key={cve.id} cve={cve} selected={selected === i}
            onClick={() => setSelected(selected === i ? null : i)} delay={i * 30} />
        ))}
        {!loading && !error && filtered.length === 0 && (
          <div style={{ color: 'var(--text-dim)', fontFamily: 'var(--font-mono)', fontSize: 11, padding: 12 }}>
            NO VULNERABILITIES MATCHING FILTER
          </div>
        )}
      </div>
    </div>
  );
}

function CVERow({ cve, selected, onClick, delay }) {
  const sc = severityColor(cve.severity);
  const sb = severityBg(cve.severity);

  return (
    <div onClick={onClick} style={{
      background: selected ? sb : 'var(--bg-card)',
      border: `1px solid ${selected ? sc + '66' : 'var(--border)'}`,
      borderLeft: `3px solid ${sc}`,
      borderRadius: 4, padding: '7px 10px', cursor: 'pointer',
      animation: `fadeIn .3s ease both`,
      animationDelay: `${delay}ms`,
      transition: 'background .15s, border-color .15s',
    }}
      onMouseEnter={e => { if (!selected) e.currentTarget.style.background = '#131e2e'; }}
      onMouseLeave={e => { if (!selected) e.currentTarget.style.background = 'var(--bg-card)'; }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: selected ? 6 : 0 }}>
        <span style={{
          fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 700,
          color: sc, background: sb, padding: '1px 5px', borderRadius: 3,
          border: `1px solid ${sc}44`, minWidth: 64, textAlign: 'center'
        }}>{cve.severity}</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--accent)', flex: 1 }}>
          {cve.id}
        </span>
        {cve.score > 0 && (
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: sc }}>
            {cve.score.toFixed(1)}
          </span>
        )}
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-dim)' }}>
          {cve.published?.split('T')[0]}
        </span>
      </div>

      {selected && (
        <div style={{ animation: 'fadeIn .2s ease', paddingTop: 4 }}>
          <p style={{ color: 'var(--text-pri)', fontSize: 11, lineHeight: 1.5, marginBottom: 6 }}>
            {cve.description}
          </p>
          {cve.references?.length > 0 && (
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {cve.references.map((r, i) => (
                <a key={i} href={r} target="_blank" rel="noreferrer" style={{
                  fontSize: 10, color: 'var(--accent)', fontFamily: 'var(--font-mono)',
                  textDecoration: 'none',
                }}>[ REF-{i + 1} ]</a>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function LoadingRows() {
  return (
    <>
      {[...Array(6)].map((_, i) => (
        <div key={i} style={{
          height: 38, background: 'var(--bg-card)', borderRadius: 4,
          border: '1px solid var(--border)', animation: 'pulse 1.5s infinite',
          animationDelay: `${i * 100}ms`
        }} />
      ))}
    </>
  );
}

function ErrorBox({ msg, onRetry }) {
  return (
    <div style={{
      background: 'var(--red-dim)', border: '1px solid var(--red)',
      borderRadius: 4, padding: 12, fontFamily: 'var(--font-mono)', fontSize: 11
    }}>
      <div style={{ color: 'var(--red)', marginBottom: 6 }}>FEED ERROR: {msg}</div>
      <div style={{ color: 'var(--text-sec)', marginBottom: 8 }}>
        NVD API may be rate-limited (1 req/6s). Try again in a moment.
      </div>
      <button onClick={onRetry} style={{ ...btnStyle, color: 'var(--red)', borderColor: 'var(--red)' }}>
        RETRY
      </button>
    </div>
  );
}

const btnStyle = {
  background: 'transparent', border: '1px solid var(--border)',
  color: 'var(--text-sec)', fontFamily: 'var(--font-mono)', fontSize: 10,
  padding: '3px 8px', borderRadius: 3, cursor: 'pointer',
  letterSpacing: '0.05em', transition: 'all .15s',
};
