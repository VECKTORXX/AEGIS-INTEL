import React, { useEffect, useRef, useState } from 'react';

const THREAT_NODES = [
  { lat: 55.75,  lon: 37.61,  label: 'Moscow',    country: 'RU', count: 4821, color: '#ef4444' },
  { lat: 39.90,  lon: 116.40, label: 'Beijing',   country: 'CN', count: 3204, color: '#f59e0b' },
  { lat: 39.02,  lon: 125.75, label: 'Pyongyang', country: 'KP', count: 1893, color: '#f59e0b' },
  { lat: 35.69,  lon: 51.39,  label: 'Tehran',    country: 'IR', count: 1241, color: '#00e5ff' },
  { lat: 30.04,  lon: 31.23,  label: 'Cairo',     country: 'EG', count:  423, color: '#00e5ff' },
  { lat: 23.13,  lon: 113.26, label: 'Guangzhou', country: 'CN', count:  982, color: '#f59e0b' },
  { lat: 59.93,  lon: 30.31,  label: 'St. Petersburg', country: 'RU', count: 1102, color: '#ef4444' },
  { lat: 48.85,  lon: 2.35,   label: 'Paris',     country: 'FR', count:  312, color: '#00ff88' },
  { lat: 51.50,  lon: -0.12,  label: 'London',    country: 'GB', count:  287, color: '#00ff88' },
  { lat: 40.71,  lon: -74.00, label: 'New York',  country: 'US', count:  198, color: '#00ff88' },
  { lat: -23.55, lon: -46.63, label: 'São Paulo', country: 'BR', count:  512, color: '#00e5ff' },
  { lat: 28.61,  lon: 77.20,  label: 'New Delhi', country: 'IN', count:  634, color: '#00e5ff' },
];

function latLonToXY(lat, lon, w, h) {
  const x = ((lon + 180) / 360) * w;
  const y = ((90 - lat) / 180) * h;
  return { x, y };
}

export default function ThreatWorldMap() {
  const canvasRef = useRef(null);
  const [hovered, setHovered] = useState(null);
  const [selected, setSelected] = useState(null);
  const animRef = useRef(0);
  const pulseRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width;
    const H = canvas.height;

    const draw = (t) => {
      ctx.clearRect(0, 0, W, H);

      // Background grid
      ctx.strokeStyle = '#0d2030';
      ctx.lineWidth = 0.5;
      for (let lon = -180; lon <= 180; lon += 30) {
        const x = ((lon + 180) / 360) * W;
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
      }
      for (let lat = -90; lat <= 90; lat += 30) {
        const y = ((90 - lat) / 180) * H;
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
      }

      // Equator highlight
      ctx.strokeStyle = '#0f3040';
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(0, H / 2); ctx.lineTo(W, H / 2); ctx.stroke();

      // Animated arcs from threat origins to center targets
      THREAT_NODES.filter(n => ['RU','CN','KP','IR'].includes(n.country)).forEach(src => {
        const s = latLonToXY(src.lat, src.lon, W, H);
        // Arc to random EU/US target
        const targets = [
          { lat: 51.5, lon: -0.12 }, { lat: 48.85, lon: 2.35 },
          { lat: 40.71, lon: -74 }, { lat: 52.52, lon: 13.4 },
        ];
        targets.forEach((tgt, ti) => {
          const e = latLonToXY(tgt.lat, tgt.lon, W, H);
          const progress = ((t * 0.0004 + ti * 0.25 + THREAT_NODES.indexOf(src) * 0.15) % 1);
          const mx = (s.x + e.x) / 2;
          const my = Math.min(s.y, e.y) - 30;

          // Draw arc
          ctx.strokeStyle = src.color + '18';
          ctx.lineWidth = 0.5;
          ctx.beginPath();
          ctx.moveTo(s.x, s.y);
          ctx.quadraticCurveTo(mx, my, e.x, e.y);
          ctx.stroke();

          // Animated dot on arc
          const bx = (1 - progress) * (1 - progress) * s.x + 2 * (1 - progress) * progress * mx + progress * progress * e.x;
          const by = (1 - progress) * (1 - progress) * s.y + 2 * (1 - progress) * progress * my + progress * progress * e.y;
          ctx.fillStyle = src.color;
          ctx.beginPath(); ctx.arc(bx, by, 2, 0, Math.PI * 2); ctx.fill();
        });
      });

      // Nodes
      THREAT_NODES.forEach(node => {
        const { x, y } = latLonToXY(node.lat, node.lon, W, H);
        const pulse = Math.sin(t * 0.003 + node.lon * 0.1) * 0.5 + 0.5;
        const r = 4 + pulse * 3;
        const isHovered = hovered === node.label;
        const isSelected = selected?.label === node.label;

        // Pulse ring
        if (['RU','CN','KP','IR'].includes(node.country)) {
          ctx.strokeStyle = node.color + '44';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.arc(x, y, r + 4 + pulse * 6, 0, Math.PI * 2);
          ctx.stroke();
        }

        // Core dot
        ctx.fillStyle = (isHovered || isSelected) ? node.color : node.color + 'bb';
        ctx.beginPath();
        ctx.arc(x, y, isHovered ? 7 : 5, 0, Math.PI * 2);
        ctx.fill();

        // Label
        if (isHovered || isSelected) {
          ctx.fillStyle = '#0d1520ee';
          const lw = node.label.length * 7 + 16;
          ctx.fillRect(x + 8, y - 10, lw, 18);
          ctx.strokeStyle = node.color + '88';
          ctx.lineWidth = 0.5;
          ctx.strokeRect(x + 8, y - 10, lw, 18);
          ctx.fillStyle = node.color;
          ctx.font = '10px "Share Tech Mono", monospace';
          ctx.fillText(`${node.label} (${node.country})`, x + 14, y + 2);
        }
      });

      animRef.current = requestAnimationFrame(draw);
    };

    animRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animRef.current);
  }, [hovered, selected]);

  const handleMouseMove = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const scaleX = canvasRef.current.width / rect.width;
    const scaleY = canvasRef.current.height / rect.height;
    const mx = (e.clientX - rect.left) * scaleX;
    const my = (e.clientY - rect.top) * scaleY;
    const W = canvasRef.current.width;
    const H = canvasRef.current.height;

    let found = null;
    THREAT_NODES.forEach(node => {
      const { x, y } = latLonToXY(node.lat, node.lon, W, H);
      if (Math.hypot(mx - x, my - y) < 12) found = node.label;
    });
    setHovered(found);
  };

  const handleClick = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const scaleX = canvasRef.current.width / rect.width;
    const scaleY = canvasRef.current.height / rect.height;
    const mx = (e.clientX - rect.left) * scaleX;
    const my = (e.clientY - rect.top) * scaleY;
    const W = canvasRef.current.width;
    const H = canvasRef.current.height;

    let found = null;
    THREAT_NODES.forEach(node => {
      const { x, y } = latLonToXY(node.lat, node.lon, W, H);
      if (Math.hypot(mx - x, my - y) < 12) found = node;
    });
    setSelected(found);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: 11, letterSpacing: '0.15em', color: 'var(--accent)' }}>
          GLOBAL THREAT MAP
        </span>
        <div style={{ display: 'flex', gap: 12, fontFamily: 'var(--font-mono)', fontSize: 10 }}>
          {[['var(--red)', 'Critical'], ['var(--amber)', 'High'], ['var(--accent)', 'Medium'], ['var(--green)', 'Low']].map(([c, l]) => (
            <span key={l} style={{ color: c, display: 'flex', alignItems: 'center', gap: 4 }}>
              <span style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: c }} />
              {l}
            </span>
          ))}
        </div>
      </div>

      <canvas ref={canvasRef} width={900} height={380}
        style={{ width: '100%', borderRadius: 4, border: '1px solid #1a3040', cursor: hovered ? 'pointer' : 'crosshair' }}
        onMouseMove={handleMouseMove}
        onMouseLeave={() => setHovered(null)}
        onClick={handleClick} />

      {selected && (
        <div style={{
          marginTop: 8, background: '#0d1520',
          border: `1px solid ${selected.color}44`,
          borderLeft: `3px solid ${selected.color}`,
          borderRadius: 4, padding: '8px 12px',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          animation: 'fadeIn .2s ease',
        }}>
          <div>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 12, color: selected.color }}>
              {selected.label}
            </span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-dim)', marginLeft: 10 }}>
              {selected.country} · {selected.lat.toFixed(2)}°N {selected.lon.toFixed(2)}°E
            </span>
          </div>
          <div style={{ textAlign: 'right' }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, color: selected.color }}>
              {selected.count.toLocaleString()}
            </span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-dim)', marginLeft: 6 }}>
              attacks/day
            </span>
          </div>
          <button onClick={() => setSelected(null)} style={{
            background: 'transparent', border: 'none', color: 'var(--text-dim)',
            cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: 12,
          }}>✕</button>
        </div>
      )}
    </div>
  );
}
