import React, { useState } from 'react';

const RISK_COLOR = score =>
  score >= 80 ? 'var(--red)' :
  score >= 40 ? 'var(--amber)' :
  score >= 10 ? 'var(--accent)' : 'var(--green)';

const RISK_LABEL = score =>
  score >= 80 ? 'CRITICAL THREAT' :
  score >= 40 ? 'HIGH RISK' :
  score >= 10 ? 'SUSPICIOUS' : 'CLEAN';

function isValidIP(ip) {
  const v4 = /^(\d{1,3}\.){3}\d{1,3}$/;
  const v6 = /^([0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}$/;
  return v4.test(ip) || v6.test(ip);
}

export default function IPScanner({ abuseIpDbKey }) {
  const [ip, setIp] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [history, setHistory] = useState([]);

  const scan = async (target) => {
    const addr = (target || ip).trim();
    if (!addr) return;
    if (!isValidIP(addr)) { setError('Invalid IP address format'); return; }
    if (!abuseIpDbKey) { setError('No AbuseIPDB key set — open Settings and add your free key'); return; }

    setLoading(true); setError(null); setResult(null);

    try {
      const res = await fetch(
        `https://api.abuseipdb.com/api/v2/check?ipAddress=${encodeURIComponent(addr)}&maxAgeInDays=90&verbose`,
        { headers: { Key: abuseIpDbKey, Accept: 'application/json' } }
      );
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      const data = await res.json();
      const d = data.data;
      const entry = {
        ip: d.ipAddress, score: d.abuseConfidenceScore,
        country: d.countryCode, isp: d.isp,
        domain: d.domain, totalReports: d.totalReports,
        lastReported: d.lastReportedAt,
        usageType: d.usageType, isWhitelisted: d.isWhitelisted,
        hostnames: d.hostnames || [],
        reports: d.reports?.slice(0, 5) || [],
        scannedAt: new Date(),
      };
      setResult(entry);
      setHistory(h => [entry, ...h.filter(x => x.ip !== entry.ip)].slice(0, 20));
      if (window.aegis && entry.score >= 80) {
        window.aegis.notify({ title: 'AEGIS — Critical IP Detected', body: `${entry.ip} has ${entry.score}% abuse confidence` });
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', gap: 10 }}>
      <span style={{ fontFamily: 'var(--font-display)', fontSize: 11, letterSpacing: '0.15em', color: 'var(--accent)' }}>
        IP REPUTATION SCANNER
      </span>

      {/* Input */}
      <div style={{ display: 'flex', gap: 6 }}>
        <input value={ip} onChange={e => setIp(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && scan()}
          placeholder="Enter IP address to scan..."
          style={{
            flex: 1, background: '#070b0f', border: '1px solid #1a3040',
            borderRadius: 4, padding: '7px 10px', color: 'var(--text-pri)',
            fontFamily: 'var(--font-mono)', fontSize: 12, outline: 'none',
            transition: 'border-color .15s',
          }}
          onFocus={e => e.target.style.borderColor = 'var(--accent)'}
          onBlur={e => e.target.style.borderColor = '#1a3040'} />
        <button onClick={() => scan()} disabled={loading || !ip.trim()} style={{
          background: '#042a30', border: '1px solid var(--accent)',
          color: 'var(--accent)', fontFamily: 'var(--font-mono)', fontSize: 11,
          padding: '7px 14px', borderRadius: 4, cursor: 'pointer',
          opacity: loading ? 0.5 : 1,
        }}>
          {loading ? 'SCANNING...' : 'SCAN →'}
        </button>
      </div>

      {!abuseIpDbKey && (
        <div style={{
          background: '#1a1a04', border: '1px solid var(--amber)', borderRadius: 4,
          padding: '7px 10px', fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--amber)',
        }}>
          ⚠ Add your free AbuseIPDB key in Settings to enable IP scanning
        </div>
      )}

      {error && (
        <div style={{
          background: '#2a0808', border: '1px solid var(--red)', borderRadius: 4,
          padding: '7px 10px', fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--red)',
        }}>{error}</div>
      )}

      {/* Result card */}
      {result && (
        <div style={{
          background: '#0d1520', border: `1px solid ${RISK_COLOR(result.score)}44`,
          borderLeft: `3px solid ${RISK_COLOR(result.score)}`,
          borderRadius: 4, padding: 12, animation: 'fadeIn .3s ease',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 14, color: 'var(--accent)', fontWeight: 700 }}>
              {result.ip}
            </span>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: RISK_COLOR(result.score) }}>
                {result.score}%
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: RISK_COLOR(result.score) }}>
                {RISK_LABEL(result.score)}
              </div>
            </div>
          </div>

          {/* Score bar */}
          <div style={{ height: 4, background: '#070b0f', borderRadius: 2, marginBottom: 10, overflow: 'hidden' }}>
            <div style={{
              height: '100%', width: `${result.score}%`,
              background: RISK_COLOR(result.score), borderRadius: 2,
              transition: 'width 1s ease',
            }} />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4px 12px' }}>
            {[
              ['Country',      result.country || 'Unknown'],
              ['ISP',          result.isp || 'Unknown'],
              ['Domain',       result.domain || 'None'],
              ['Usage type',   result.usageType || 'Unknown'],
              ['Total reports',result.totalReports],
              ['Whitelisted',  result.isWhitelisted ? 'Yes' : 'No'],
            ].map(([k, v]) => (
              <div key={k} style={{ display: 'flex', gap: 6, padding: '3px 0' }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-dim)', minWidth: 80 }}>{k}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-pri)' }}>{v}</span>
              </div>
            ))}
          </div>

          {result.lastReported && (
            <div style={{ marginTop: 6, fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-dim)' }}>
              Last reported: <span style={{ color: 'var(--text-sec)' }}>{result.lastReported?.split('T')[0]}</span>
              &nbsp;·&nbsp;Scanned: <span style={{ color: 'var(--text-sec)' }}>{result.scannedAt.toTimeString().split(' ')[0]}</span>
            </div>
          )}
        </div>
      )}

      {/* Scan history */}
      {history.length > 0 && (
        <div style={{ flex: 1, overflowY: 'auto' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 10, letterSpacing: '0.12em', color: 'var(--text-dim)', marginBottom: 6 }}>
            SCAN HISTORY
          </div>
          {history.map((h, i) => (
            <div key={i} onClick={() => { setIp(h.ip); setResult(h); }}
              style={{
                display: 'flex', alignItems: 'center', gap: 8,
                background: '#0d1520', border: '1px solid #1a3040',
                borderLeft: `3px solid ${RISK_COLOR(h.score)}`,
                borderRadius: 4, padding: '5px 8px', marginBottom: 4,
                cursor: 'pointer', transition: 'border-color .15s',
              }}
              onMouseEnter={e => e.currentTarget.style.borderColor = RISK_COLOR(h.score)}
              onMouseLeave={e => e.currentTarget.style.borderColor = '#1a3040'}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--accent)', flex: 1 }}>{h.ip}</span>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-dim)' }}>{h.country}</span>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: RISK_COLOR(h.score), fontWeight: 700 }}>{h.score}%</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
