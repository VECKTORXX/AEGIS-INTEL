import React, { useState, useEffect } from 'react';

export default function TitleBar() {
  const [time, setTime] = useState('');
  const [date, setDate] = useState('');

  useEffect(() => {
    const tick = () => {
      const now = new Date();
      setTime(now.toUTCString().split(' ')[4] + ' UTC');
      setDate(now.toISOString().split('T')[0]);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      height: 40, padding: '0 16px',
      background: 'var(--bg-panel)',
      borderBottom: '1px solid var(--border)',
      WebkitAppRegion: 'drag',
      flexShrink: 0,
    }}>
      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 8, height: 8, borderRadius: '50%',
          background: 'var(--accent)', animation: 'pulse 2s infinite'
        }} />
        <span style={{
          fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700,
          letterSpacing: '0.2em', color: 'var(--accent)'
        }}>AEGIS INTEL</span>
        <span style={{ color: 'var(--text-dim)', fontSize: 11, fontFamily: 'var(--font-mono)' }}>
          v2.4.1
        </span>
      </div>

      {/* Center: date + time */}
      <div style={{
        fontFamily: 'var(--font-mono)', fontSize: 12,
        color: 'var(--text-sec)', letterSpacing: '0.05em'
      }}>
        <span style={{ marginRight: 16, color: 'var(--text-dim)' }}>{date}</span>
        <span style={{ color: 'var(--accent)' }}>{time}</span>
      </div>

      {/* Window controls */}
      <div style={{
        display: 'flex', gap: 8, WebkitAppRegion: 'no-drag'
      }}>
        {[
          { label: '–', action: 'minimizeWindow', color: 'var(--amber)' },
          { label: '□', action: 'maximizeWindow', color: 'var(--accent)' },
          { label: '✕', action: 'closeWindow',    color: 'var(--red)'   },
        ].map(({ label, action, color }) => (
          <button key={action} onClick={() => window.aegis?.[action]?.()}
            style={{
              width: 22, height: 22, borderRadius: '50%',
              background: 'var(--bg-base)', border: `1px solid ${color}44`,
              color, fontSize: 11, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'background .15s, border-color .15s',
              fontFamily: 'var(--font-mono)',
            }}
            onMouseEnter={e => { e.currentTarget.style.background = color + '22'; e.currentTarget.style.borderColor = color; }}
            onMouseLeave={e => { e.currentTarget.style.background = 'var(--bg-base)'; e.currentTarget.style.borderColor = color + '44'; }}
          >{label}</button>
        ))}
      </div>
    </div>
  );
}
