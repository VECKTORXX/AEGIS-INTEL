import React, { useState, useEffect, useCallback } from 'react';
import TitleBar from './components/TitleBar';
import StatusBar from './components/StatusBar';
import Sidebar from './components/Sidebar';
import CVEFeed from './components/CVEFeed';
import AIAnalyst from './components/AIAnalyst';
import ThreatMetrics from './components/ThreatMetrics';
import IPScanner from './components/panels/IPScanner';
import ThreatWorldMap from './components/panels/ThreatWorldMap';
import SettingsModal from './components/modals/SettingsModal';
import { requestNotificationPermission } from './services/notificationService';
import { exportThreatReport } from './services/reportService';
import { fetchLatestCVEs } from './services/cveService';

const DEFAULT_CONFIG = {
  abuseIpDbKey:   '',
  ollamaModel:    'mistral',
  ollamaUrl:      'http://localhost:11434',
  cveLimit:       20,
  cveRefreshMins: 15,
  notifyCritical: true,
  notifyHigh:     false,
  notifyNewIP:    true,
  watchKeywords:  'nginx, openssl, windows, apache, docker',
  operatorName:   '',
};

const PANEL = {
  background: 'var(--bg-panel)',
  border: '1px solid var(--border)',
  borderRadius: 6, padding: 14,
  overflow: 'hidden', display: 'flex', flexDirection: 'column',
};

export default function App() {
  const [view, setView]             = useState('dashboard');
  const [showSettings, setShowSettings] = useState(false);
  const [config, setConfig]         = useState(() => {
    try { return { ...DEFAULT_CONFIG, ...JSON.parse(localStorage.getItem('aegis-config') || '{}') }; }
    catch { return DEFAULT_CONFIG; }
  });
  const [cves, setCves]             = useState([]);
  const [cveCount, setCveCount]     = useState(0);
  const [aiStatus, setAiStatus]     = useState('offline');
  const [alertCount, setAlertCount] = useState(0);

  useEffect(() => { requestNotificationPermission(); }, []);

  useEffect(() => {
    if (!config.cveRefreshMins) return;
    const id = setInterval(async () => {
      const data = await fetchLatestCVEs();
      if (!data?.error) { setCves(data); setCveCount(data.length); }
    }, config.cveRefreshMins * 60 * 1000);
    return () => clearInterval(id);
  }, [config.cveRefreshMins]);

  const saveConfig = useCallback((cfg) => {
    setConfig(cfg);
    try { localStorage.setItem('aegis-config', JSON.stringify(cfg)); } catch {}
    setShowSettings(false);
  }, []);

  const handleNav = (id) => {
    if (id === 'settings') { setShowSettings(true); return; }
    setView(id);
    if (id === 'cve') setAlertCount(0);
  };

  const renderMain = () => {
    switch (view) {
      case 'dashboard':
        return (
          <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gridTemplateRows: '1fr 1fr', gap: 8, flex: 1, overflow: 'hidden' }}>
            <div style={{ ...PANEL, gridRow: '1 / 3' }}>
              <ThreatMetrics cveCount={cveCount} />
            </div>
            <div style={PANEL}>
              <ThreatWorldMap />
            </div>
            <div style={PANEL}>
              <AIAnalyst onStatusChange={setAiStatus} config={config} />
            </div>
          </div>
        );
      case 'cve':
        return (
          <div style={{ ...PANEL, flex: 1 }}>
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 10 }}>
              <button onClick={() => exportThreatReport({ cves, config })} style={{
                background: '#042a30', border: '1px solid var(--accent)',
                color: 'var(--accent)', fontFamily: 'var(--font-mono)',
                fontSize: 10, padding: '4px 10px', borderRadius: 4, cursor: 'pointer',
              }}>↓ EXPORT PDF REPORT</button>
            </div>
            <CVEFeed
              onThreatCountChange={count => { setCveCount(count); setAlertCount(count); setCves([]); }}
              config={config} />
          </div>
        );
      case 'map':
        return <div style={{ ...PANEL, flex: 1 }}><ThreatWorldMap /></div>;
      case 'ipscan':
        return <div style={{ ...PANEL, flex: 1 }}><IPScanner abuseIpDbKey={config.abuseIpDbKey} /></div>;
      case 'ai':
        return <div style={{ ...PANEL, flex: 1 }}><AIAnalyst onStatusChange={setAiStatus} config={config} /></div>;
      default:
        return null;
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: 'var(--bg-base)', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 999, overflow: 'hidden', opacity: 0.025 }}>
        <div style={{ width: '100%', height: 2, background: 'var(--accent)', animation: 'scanline 4s linear infinite' }} />
      </div>

      <TitleBar />

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden', gap: 8, padding: 8 }}>
        <Sidebar active={view} onNav={handleNav} alertCount={alertCount} />
        {renderMain()}
      </div>

      <StatusBar threatCount={247 + cveCount} cveCount={cveCount} aiStatus={aiStatus} />

      {showSettings && (
        <SettingsModal config={config} onSave={saveConfig} onClose={() => setShowSettings(false)} />
      )}
    </div>
  );
}
